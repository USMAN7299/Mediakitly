# MediaKitly monetization foundation (starter)

This package extends the uploaded V2 static website. It adds a Cloudflare Pages Functions API foundation, D1 schema, a provisional pricing page and an Adsterra configuration placeholder.

## Important status

This is an implementation starter, **not a production-ready payment or subscription system**.

- Existing image/video tools remain browser-side.
- Registration/login API uses PBKDF2 password hashing and HttpOnly session cookies.
- Email verification, password reset, abuse throttling and full account-management UI are not implemented.
- Usage counters are API scaffolding. They do not yet securely gate every browser-side operation. A client-side-only tool can be bypassed; strict quotas require the operation to be enforced by a trusted backend or controlled server API.
- Safepay checkout and webhook endpoints deliberately return `503` until a real merchant account, plan ID, server key, webhook secret and the provider's current signing specification are configured and tested.
- Adsterra ads are disabled. Insert only the actual site/zone code from your publisher dashboard after approval. Never use guessed publisher IDs or ad scripts.
- The proposed Rs 499 Pro price and usage limits are not market-tested.

## Cloudflare deployment note

Your existing project is a Pages **Direct Upload** project. Cloudflare's dashboard drag-and-drop upload does not execute Pages Functions. Use Wrangler CLI to deploy the Functions-enabled project, or create a separate Git-integrated Pages project. Do not assume re-uploading this ZIP through the dashboard activates `/api/*`.

Cloudflare docs:
- Pages Functions: https://developers.cloudflare.com/pages/functions/get-started/
- D1 bindings: https://developers.cloudflare.com/pages/functions/bindings/
- Direct Upload: https://developers.cloudflare.com/pages/get-started/direct-upload/

## Setup

1. Install Node.js LTS.
2. Extract this ZIP.
3. In the project folder run `npm install`.
4. Create a D1 database: `npx wrangler d1 create mediakitly-db`.
5. Copy the returned database ID into `wrangler.toml`.
6. Replace the `name` in `wrangler.toml` with your existing Cloudflare Pages project name.
7. Apply the schema locally/remote:
   - Local: `npx wrangler d1 execute mediakitly-db --local --file=sql/schema.sql`
   - Remote: `npx wrangler d1 execute mediakitly-db --remote --file=sql/schema.sql`
8. Test locally: `npm run dev`.
9. Deploy using `npm run deploy` after confirming your Pages project supports the Functions deployment workflow. Keep a backup of the current live deployment.

## API routes currently included

- `GET /api/health`
- `GET /api/plans`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/me`
- `GET /api/usage`
- `POST /api/usage/consume` (counter scaffold; not yet a secure gate for local browser operations)
- `POST /api/billing/checkout` (intentionally disabled until Safepay is configured)
- `POST /api/webhooks/safepay` (intentionally disabled until webhook verification is implemented)

## Safepay

Do not enter live credentials until merchant onboarding is approved. Use Safepay's current official integration docs and sandbox. Implement webhook signature verification and idempotent event handling before enabling paid access. Activate Pro only from verified successful subscription payment events, never from a browser redirect.

## Adsterra

Keep `assets/monetization-config.js` disabled until Adsterra provides actual placement code. Do not put private API keys in browser files. Avoid popunders and ads near upload/edit/download controls. Update the Privacy Policy and consent handling before serving ads.

## Before public launch

- Add email verification and password reset.
- Add rate limiting and bot protection to auth endpoints.
- Add CSRF protections appropriate to the final session/origin setup.
- Add user-facing signup/login/account pages.
- Integrate each tool action with server-verified entitlements or clearly keep the tools free without hard quotas.
- Implement Safepay webhook signature verification, event idempotency, renewal, cancellation, refunds and failed-payment handling.
- Add real Adsterra placement snippets only after publisher approval.
- Replace the contact email placeholder and revise Privacy/Terms.
- Have the security and privacy implementation reviewed before accepting payments.
